#!/bin/bash

function main()
{
	old_cwd=`pwd`
	script_dir=`dirname $0`
	cd $script_dir

	./install.py --silent
	echo "[x] finish to call safedog install script!" 
	cd $old_cwd
}
#start the up.sh
main
